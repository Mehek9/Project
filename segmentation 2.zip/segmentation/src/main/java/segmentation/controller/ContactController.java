package segmentation.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import segmentation.model.Contact;
import segmentation.service.ContactService;

import java.util.List;

@RestController
@RequestMapping("/api/contacts")
public class ContactController {
 
    @Autowired
    private ContactService contactService;
 
    @GetMapping("/segmentation/{category}")
    public ResponseEntity<List<Contact>> segmentContactsByCategory(@PathVariable String category) {
        List<Contact> segmentedContacts = contactService.segmentContactsByCategory(category);
        return new ResponseEntity<>(segmentedContacts, HttpStatus.OK);
    }
}