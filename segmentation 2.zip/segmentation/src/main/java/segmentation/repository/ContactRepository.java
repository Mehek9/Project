package segmentation.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import segmentation.model.Contact;

  // Add custom query methods if needed



public interface ContactRepository extends JpaRepository<Contact, Long> {
    List<Contact> findByCategory(String category);
}