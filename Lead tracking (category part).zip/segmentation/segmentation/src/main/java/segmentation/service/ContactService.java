package segmentation.service;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import segmentation.model.Contact;
import segmentation.model.SegmentedContact;
import segmentation.repository.ContactRepository;
import segmentation.repository.SegmentedContactRepository;
 
import java.util.Date;
import java.util.List;
 
@Service
public class ContactService {
 
    @Autowired
    private ContactRepository contactRepository;
 
    @Autowired
    private SegmentedContactRepository segmentedContactRepository;
 
    public List<Contact> segmentContactsByCategory(String category) {
        return contactRepository.findByCategory(category);
    }
 
    public List<Contact> segmentContactsByCountry(String country) {
        return contactRepository.findByCountry(country);
    }
 
    public List<Contact> segmentContactsByDate(Date fromDate, Date toDate) {
        return contactRepository.findByDateCreatedBetween(fromDate, toDate);
    }
 
    public void saveContacts(List<Contact> contacts) {
        contactRepository.saveAll(contacts);
    }
 
    public void saveSegmentedContacts(List<SegmentedContact> segmentedContacts) {
        segmentedContactRepository.saveAll(segmentedContacts);
    }
}