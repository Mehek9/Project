package segmentation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import segmentation.model.AssignedContact;
import segmentation.model.Contact;
import segmentation.service.AssignedContactService;
import segmentation.service.ContactService;

import java.util.Date;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin
@RequestMapping("/api/contacts")
public class ContactController {
    @Autowired
    private ContactService contactService;

    @Autowired
    private AssignedContactService assignedContactService;

    @GetMapping("segmentation/{segmentType}")
    public ResponseEntity<List<Contact>> segmentContacts(@PathVariable String segmentType,
                                                          @RequestParam(required = false) String value,
                                                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date fromDate,
                                                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") Date toDate) {
        List<Contact> segmentedContacts;
        if ("category".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByCategory(value);
        } else if ("country".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByCountry(value);
        } else if ("date".equals(segmentType)) {
            segmentedContacts = contactService.segmentContactsByDate(fromDate, toDate);
        } else {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }

        contactService.saveContacts(segmentedContacts);

        return new ResponseEntity<>(segmentedContacts, HttpStatus.OK);
    }

    @PostMapping("/assign")
    public ResponseEntity<List<AssignedContact>> assignContacts(@RequestBody Map<String, Object> requestBody) {
        String segmentType = (String) requestBody.get("segmentType");
        String value = (String) requestBody.get("value");
        String assignedTo = (String) requestBody.get("assignedTo");
        String status = (String) requestBody.get("status");

        List<Contact> segmentedContacts = null;

        if (segmentType != null && value != null) {
            if ("category".equals(segmentType)) {
                segmentedContacts = contactService.segmentContactsByCategory(value);
            } else if ("country".equals(segmentType)) {
                segmentedContacts = contactService.segmentContactsByCountry(value);
            } else if ("date".equals(segmentType)) {
                segmentedContacts = contactService.segmentContactsByDate(null, null); // Implement logic for date segmentation
            }
        }

        if (segmentedContacts == null) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

        List<AssignedContact> assignedContacts = assignedContactService.assignContacts(segmentedContacts, segmentType, value, assignedTo, status);
        return new ResponseEntity<>(assignedContacts, HttpStatus.OK);
    }
}
