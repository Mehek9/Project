package segmentation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import segmentation.model.AssignedContact;
import segmentation.model.Contact;
import segmentation.repository.AssignedContactRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class AssignedContactService {

    @Autowired
    private AssignedContactRepository assignedContactRepository;

    public List<AssignedContact> assignContacts(List<Contact> contacts, String segmentType, String value, String assignedTo, String status) {
        List<AssignedContact> assignedContacts = new ArrayList<>();
        for (Contact contact : contacts) {
            AssignedContact assignedContact = new AssignedContact();
            assignedContact.setName(contact.getName());
            assignedContact.setEmail(contact.getEmail());
            assignedContact.setCategory(contact.getCategory());
            assignedContact.setPhoneNumber(contact.getPhoneNumber());
            assignedContact.setCountry(contact.getCountry());
            assignedContact.setAssignedTo(assignedTo);
            assignedContact.setStatus(status);
            assignedContact.setDateCreated(contact.getDateCreated());

            assignedContacts.add(assignedContact);
        }
        assignedContactRepository.saveAll(assignedContacts);

        return assignedContacts;
    }
}
