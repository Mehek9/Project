package segmentation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import segmentation.model.AssignedContact;

public interface AssignedContactRepository extends JpaRepository<AssignedContact, Long> {
    
}
