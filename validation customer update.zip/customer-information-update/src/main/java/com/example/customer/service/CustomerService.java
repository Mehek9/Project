
package com.example.customer.service;

import com.example.customer.entity.Customer;

public interface CustomerService {
    Customer updateCustomer(Long id, Customer customer);
}
