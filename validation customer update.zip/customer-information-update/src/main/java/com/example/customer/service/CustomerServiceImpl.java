package com.example.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.customer.entity.Customer;
import com.example.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
    
    @Autowired
    private CustomerRepository customerRepository;
    
    @Override
    public Customer updateCustomer(Long id, Customer customer) {
        // Find the customer by id
        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id: " + id));
        
        // Update the customer information
        if (customer.getName() != null) {
            existingCustomer.setName(customer.getName());
        }
        if (customer.getCategory() != null) {
            existingCustomer.setCategory(customer.getCategory());
        }
        if (customer.getPhoneNumber() != 0) { // Check if phone number is not zero
            existingCustomer.setPhoneNumber(customer.getPhoneNumber());
        }
        if (customer.getEmail() != null) {
            existingCustomer.setEmail(customer.getEmail());
        }
        if (customer.getCountry() != null) {
            existingCustomer.setCountry(customer.getCountry());
        }
        
        // Save the updated customer
        return customerRepository.save(existingCustomer);
    }
}
